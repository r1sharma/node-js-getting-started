import jenkins.model.*

node {
    
    /*stage('delete dir'){
        cleanWs()
    }
    

    stage('checkout') {
        checkout scm
        sh('pwd; ls -l')
    }*/

    stage('checkout node package'){
        sh('pwd; ls -l')
        sh('npm -v')
    }

    //stage('publish node package to Nexus'){}

    stage('deploy node package to Heroku Dev Instance'){

        sh('which heroku')
        //show list of apps on heroku pipline
        sh ('heroku pipelines:info sfdc-it-apps-kernel-pipeline')
    }

    stage('try heroku apis'){

        sh '''
        curl -nX GET https://api.heroku.com/apps -H "Accept: application/vnd.heroku+json; version=3"
        '''
    }

    stage('deploy node package to Heroku QA Instance'){}
}